package in.yaseenkirana.store;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.content.ActivityNotFoundException;
import android.os.Bundle;
import android.os.Build;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.SharedPreferences;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.json.JSONObject;
import com.google.firebase.messaging.FirebaseMessaging;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends Activity {
    private static final int LOCATION_REQUEST = 4102;
    private WebView webView;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private static final String TRUSTED_HOST = "mystore2.shahrukhkhan16805.workers.dev";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        createStoreNotificationChannel();
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4103);
        }
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // Required by the existing store website.
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setGeolocationEnabled(true);
        webView.addJavascriptInterface(new StoreBridge(), "YaseenNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                String host = uri.getHost();
                if ("https".equalsIgnoreCase(scheme) && host != null &&
                    (host.equals(TRUSTED_HOST) || host.equals("mlywhehhjppwwjnxxspf.supabase.co"))) return false;
                // Permit payment-app handoff and ordinary external HTTPS links through Android's app chooser/browser.
                if ("upi".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme) || "mailto".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (ActivityNotFoundException ignored) { }
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (!origin.startsWith("https://" + TRUSTED_HOST)) { callback.invoke(origin, false, false); return; }
                if (hasLocationPermission()) { callback.invoke(origin, true, false); return; }
                pendingGeoOrigin = origin;
                pendingGeoCallback = callback;
                ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
            }
        });
        webView.loadUrl(BuildConfig.START_URL);
    }


    private void createStoreNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(new NotificationChannel(
                "yaseen_store_updates", "Store updates", NotificationManager.IMPORTANCE_DEFAULT));
        }
    }

    private class StoreBridge {
        @JavascriptInterface public void registerCustomerDevice(String orderId, String phone) {
            if (!"customer".equals(BuildConfig.APP_ROLE) || orderId == null || phone == null) return;
            registerFcmToken("customer", orderId.trim(), phone.trim(), null);
        }
        @JavascriptInterface public void registerAdminDevice(String accessToken) {
            if (!"admin".equals(BuildConfig.APP_ROLE) || accessToken == null || accessToken.length() < 40) return;
            registerFcmToken("admin", null, null, accessToken);
        }
    }

    private void registerFcmToken(String role, String orderId, String phone, String accessToken) {
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (!task.isSuccessful() || task.getResult() == null) return;
            final String token = task.getResult();
            new Thread(() -> {
                HttpURLConnection conn = null;
                try {
                    SharedPreferences prefs = getSharedPreferences("yaseen_fcm", MODE_PRIVATE);
                    String installationId = prefs.getString("installation_id", null);
                    if (installationId == null) { installationId = UUID.randomUUID().toString(); prefs.edit().putString("installation_id", installationId).apply(); }
                    JSONObject payload = new JSONObject();
                    payload.put("action", "register_device"); payload.put("app_role", role);
                    payload.put("installation_id", installationId); payload.put("fcm_token", token);
                    if ("customer".equals(role)) { payload.put("order_id", orderId); payload.put("phone", phone); }
                    URL url = new URL(BuildConfig.FCM_FUNCTION_URL);
                    conn = (HttpURLConnection) url.openConnection(); conn.setRequestMethod("POST");
                    conn.setConnectTimeout(12000); conn.setReadTimeout(12000); conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY);
                    if (accessToken != null) conn.setRequestProperty("Authorization", "Bearer " + accessToken);
                    byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
                    try (OutputStream out = conn.getOutputStream()) { out.write(bytes); }
                    int status = conn.getResponseCode();
                    if (status >= 200 && status < 300) prefs.edit().putString("registered_role", role).apply();
                } catch (Exception ignored) {
                    // Registration is retried next time the verified tracking/admin session opens.
                } finally { if (conn != null) conn.disconnect(); }
            }).start();
        });
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == LOCATION_REQUEST && pendingGeoCallback != null) {
            boolean granted = hasLocationPermission();
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null; pendingGeoOrigin = null;
            if (!granted) Toast.makeText(this, "Location permission nahi mili. Address manually bhar sakte hain.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
