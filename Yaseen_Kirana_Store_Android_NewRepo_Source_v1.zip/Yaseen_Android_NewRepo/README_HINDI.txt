YASEEN KIRANA STORE - CLEAN ANDROID REPOSITORY

Is ZIP ko ek nayi, empty GitHub repository ke main branch me extract karke upload karein.

Files/folders ka structure bilkul aisa hi rehna chahiye:
- app/
- .github/workflows/main.yml
- build.gradle
- settings.gradle
- gradle.properties
- README_HINDI.txt

GitHub Actions > main workflow > Run workflow se build chalayen.

IMPORTANT SIGNING:
APK ko signed release banane ke liye repository Settings > Secrets and variables > Actions me ye 4 secrets banayein:
1. ANDROID_KEYSTORE_BASE64 = .jks file ka Base64 text
2. ANDROID_KEYSTORE_PASSWORD = keystore password
3. ANDROID_KEY_ALIAS = key alias
4. ANDROID_KEY_PASSWORD = key password

Private key/keystore ko repository ya ZIP me kabhi upload na karein.

Agar ye secrets set nahi hain, workflow sirf DEBUG APK banayega. Debug APK ko public Install button par na lagayein.

Old installed APK se private signing key extract/recover nahi hoti. Nayi key se bane release APK purane, alag key se signed APK ko update nahi kar sakte. Package IDs abhi purane project ke anuroop hain:
Customer: in.yaseenkirana.store.customer
Admin: in.yaseenkirana.store.admin

Firebase google-services.json is project ke maujooda Android app registrations ka config hai. Firebase console me dono package IDs registered hone chahiye.
